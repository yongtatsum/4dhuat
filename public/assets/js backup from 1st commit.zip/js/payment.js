(function(window, $) {
	$(function() {
		$('#btn-close').click(function() {
      window.location.href = 'property.wonderlist.wonderlist://closeClicked';
		});

		$('#btn-success').click(function() {
      window.location.href = 'property.wonderlist.wonderlist://successClicked';
		});

	});
} (window, jQuery));
