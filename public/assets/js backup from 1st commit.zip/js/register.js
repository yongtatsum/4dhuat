(function(window, $) {
	$(function() {

		// $('#agent').click(function(){
		// 	if ($(this).is(':checked')) {
		// 		$('#agency').removeClass('hide');
		// 	} else {	
		// 		$('#agency').addClass('hide');
		// 	}
			
		// });

	    $('#dob').combodate({
			value: new Date(),
			minYear: 1900,
			maxYear: moment().format('YYYY')  
    	});  
		
	});
} (window, jQuery));